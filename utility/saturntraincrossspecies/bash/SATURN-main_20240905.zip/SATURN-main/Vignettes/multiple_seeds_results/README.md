# Running SATURN multiple times

This directory will contain the results of running SPEAR many times.

For analysis on both frog and zebrafish embryogenesis, we ran SATURN 30 times.